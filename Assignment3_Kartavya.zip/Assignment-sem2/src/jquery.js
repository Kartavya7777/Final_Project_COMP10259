
let index = 0;
const totalWorkItems = $(".work-item").length; 
$(document).ready(function() {


    $(".nav-toggle").click(function(){
        $(".header .nav").slideToggle();
      })
      $(".header .nav a").click(function(){
        if($(window).width() < 768){
           $(".header .nav").slideToggle();
        }
      })
      
    $(window).scroll(function(){
        if($(this).scrollTop() > 100){
            $(".header").addClass("fixed");
        }
        else{
            $(".header").removeClass("fixed");
        }
    })



    var $galleryItems = $('#gallery .media figure');
    var $lightbox = $('#lightbox');
    var $lightboxContent = $('#lightbox-content');
    var currentIndex = -1;

    $galleryItems.on('click', function() {
        currentIndex = $galleryItems.index(this);
        showLightbox(currentIndex);
    });

    function showLightbox(index) {
        var $item = $galleryItems.eq(index);
        var content = $item.html();
        $lightboxContent.html(content);
        $('#lightbox-overlay, #lightbox').fadeIn();
    }

    function hideLightbox() {
        $('#lightbox-overlay, #lightbox').fadeOut();
    }

    function showNext() {
        if (currentIndex < $galleryItems.length - 1) {
            currentIndex++;
        } else {
            currentIndex = 0;
        }
        showLightbox(currentIndex);
    }

    function showPrev() {
        if (currentIndex > 0) {
            currentIndex--;
        } else {
            currentIndex = $galleryItems.length - 1;
        }
        showLightbox(currentIndex);
    }

    $('#close-lightbox, #lightbox-overlay').on('click', hideLightbox);
    $('#next').on('click', showNext);
    $('#prev').on('click', showPrev);

    $(document).keyup(function(e) {
        if (e.key === "Escape") hideLightbox();
        if (e.key === "ArrowRight") showNext();
        if (e.key === "ArrowLeft") showPrev();
    });
// Set lightbox img max height after clicking
const wHeight = $(window).height();
$(".lightbox-img").css("max-height",wHeight+"px");

// Lightbox Slideshow Code 
$(".work-item-inner").click(function(){
    index = $(this).parent(".work-item").index();
    $(".lightbox").addClass("open");
    lightboxSlideShow();
})
$(".lightbox .prev").click(function(){
 if(index == 0){
      index = totalWorkItems-1;
 }
 else{
     index--;
 }
 lightboxSlideShow();
})
$(".lightbox .next").click(function(){
    if(index == totalWorkItems-1){
        index = 0
    }
    else{
        index++;
    }
    lightboxSlideShow();
})

// Closing the lightbox on Click
$(".lightbox-close").click(function(){
  
    $(".lightbox").hide();
})

// Close lightbox when clicked outside of img-box 
$(".lightbox").click(function(event){
 if($(event.target).hasClass("lightbox")){
    
    $(this).hide();
 }
})
})

function lightboxSlideShow(){
    const imgSrc = $(".work-item").eq(index).find("img").attr("data-large");
    $(".lightbox-img").attr("src",imgSrc);
   

  }